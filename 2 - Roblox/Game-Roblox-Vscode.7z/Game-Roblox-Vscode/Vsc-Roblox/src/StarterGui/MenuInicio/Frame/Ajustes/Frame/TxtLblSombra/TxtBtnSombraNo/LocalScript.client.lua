script.Parent.MouseButton1Click:Connect(function() -- Conecte una función a la señal MouseButton1Click del objeto de la instancia de script (MouseButton1Click es la señal que se activa cuando se hace clic en el objeto de la instancia de script)
	game.Lighting.GlobalShadows = false -- Establezca la propiedad GlobalShadows del objeto de la instancia de juego en falso (GlobalShadows es la propiedad que controla si las sombras globales están habilitadas)
end) -- Termine la función
